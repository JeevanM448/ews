from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from backend.services.data_service import get_environmental_data
from backend.services.risk_engine import environmental_risk_engine
import logging

# ... existing imports
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

# Initialize FastAPI app
app = FastAPI(title="Environmental Risk Prediction System", version="1.0.0")

# Configure CORS
origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "*", 
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Endpoint for simplified risk assessment
@app.get("/risk")
async def get_simplified_risk(
    lat: float = Query(..., description="Latitude"),
    lon: float = Query(..., description="Longitude")
):
    """
    Get temperature, humidity, PM2.5, risk level (score), and severity label.
    """
    try:
        result = await environmental_risk_engine.analyze_risk(lat, lon)
        metrics = result["aggregated_metrics"]
        
        return {
            "temperature": metrics["temperature"],
            "humidity": metrics["humidity"],
            "pm25": metrics["pm25"],
            "uv_index": metrics.get("uv_index"),
            "rainfall": metrics.get("rainfall"),
            "risk_level": result["score"],
            "severity_label": result["severity_label"],
            "social_stress_score": result["social_overlay"]["score"]
        }
    except Exception as e:
        logger.error(f"Error in /risk endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Endpoint for raw aggregated environmental data
@app.get("/api/environmental-data")
async def get_env_data(
    lat: float = Query(..., description="Latitude"),
    lon: float = Query(..., description="Longitude")
):
    """
    Get comprehensive environmental data including weather features, 
    air quality pollutants, and time-based metrics.
    """
    return await get_environmental_data(lat, lon)

@app.get("/api/risk-data")
async def get_risk_data(
    lat: float = Query(..., description="Latitude"),
    lon: float = Query(..., description="Longitude")
):
    try:
        # Use the centralized Risk Engine
        risk_result = await environmental_risk_engine.analyze_risk(lat, lon)
        
        # Structure for Frontend Compatibility
        # The engine logic handles data fetching, ML, and heuristics
        
        return {
            "location": {"lat": lat, "lon": lon},
            # Map engine output to frontend needs
            "weather": risk_result["raw_data"]["raw_weather"],
            "air_quality": risk_result["raw_data"]["raw_aqi"],
            "risk_assessment": {
                "score": risk_result["score"],
                "level": risk_result["severity_label"],
                "factors": risk_result["contributing_factors"],
                "ml_model_prediction": risk_result["ml_prediction"]["label"],
                "ml_raw_output": risk_result["ml_prediction"]["raw_value"],
                "social_stress_score": risk_result["social_overlay"]["score"],
                "social_severity": risk_result["social_overlay"]["severity"],
                "recent_social_sentiment": risk_result["social_overlay"]["sentiment_average"],
                "timestamp": "now"
            },
            "social_data": risk_result["social_overlay"],
            "environmental_data": risk_result["environmental_base"],
            "aggregated_metrics": risk_result["aggregated_metrics"]
        }
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        status_code = 500
        if "No data found" in str(e):
             status_code = 404
        raise HTTPException(status_code=status_code, detail=str(e))

# Mount static files (Frontend)
# Ensure the directory exists relative to execution context
frontend_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
else:
    logger.warning("Frontend directory not found. Serving API only.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)

